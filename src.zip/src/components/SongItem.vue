<template>
    <div 
        class="song-item"
        @click="pushSong"
    >
        <div class="l">
            <div class="index" v-if="false">3</div>
            <div class="filename">{{fileName}}</div>
        </div>
        <div class="r">
            <img src="../assets/image/download_icon_2.png" alt="">
        </div>
    </div>
</template>

<script>
export default {
    props: ['fileName','hash'],
    data() {
        return {
            
        }
    },
    methods: {
        pushSong() {
            this.$store.commit('pushSong',this.hash)
        }
    }
}
</script>

<style lang="less" scoped>
    .song-item{
        font-size: 0.36rem;
        line-height: 0.4rem;
        display: flex;
        align-items: center;
        height: 1.4rem;
        margin-left: 0.2rem;
        padding-right: 0.2rem;
        border-bottom: 0.01rem solid #e5e5e5;
        .l{
            flex: 1;
            display: flex;
            .index{
                width: 0.46rem;
                line-height: 0.3rem;
                font-size: 0.12rem;
                text-align: center;
                margin-right: 0.1rem;
                border-radius: 0.12rem;
                background-color: red;
            }
            .filename{
                padding-left: 0.1rem;
            }
        }
        .r{
            width: 0.5rem;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            img{
                width: 0.33rem;
                height: 0.34rem;
            }
        }
    }
</style>
