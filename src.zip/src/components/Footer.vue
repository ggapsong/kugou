<template>
    <div class="footer" v-if="song">
        <div class="left">
            <img class="song-pic" src="../assets/image/song-pic.png" alt="">
            <div class="song-info">
                <div class="song-name">{{songData.songName}}</div>
                <div class="songer">{{songData.singerName}}</div>
            </div>
        </div>
        <div class="right">
            <img src="../assets/image/play.png" v-if="!playing" alt="" @click="play">
            <img src="../assets/image/stop.png" v-else alt="" @click="stop">
            <img src="../assets/image/next.png" alt="">
            <img src="../assets/image/down.png" alt="">
        </div>
        <audio 
            v-show="false"
            :src="songData.url"
            ref="audio"
        ></audio>
    </div>
</template>

<script>
export default {
    data(){
        return {
            //歌曲信息
            songData:{},
            playing:false
        }
    },
    methods:{
        //播放
        play(){
            this.$refs.audio.play();
            this.playing = true;
        },//暂停
        stop(){
            this.$refs.audio.pause(); 
            this.playing = false;
        }
    },
    computed:{
        song(){
            return this.$store.state.song;
        }
    },
    watch:{
        song(){
            this.$ajax({
                url:"/api/app/i/getSongInfo.php?cmd=playInfo&hash="+this.song
            }).then((res)=>{
                this.songData = res.data;
                console.log(res.data)
                this.$nextTick(()=>{
                    this.$refs.audio.load();
                    this.play();
                })
            })
        }
    }
}
</script>

<style lang="less" scoped>
.footer{
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    height:1.01rem;
    background-color: #191919;
    :after{
        clear: both;
        display: block;
        content: ""
    }
    .left{
        float: left;
         .song-pic{
            width: 0.9rem;
            height: 0.9rem;
            margin:0.05rem 0.13rem 0 0.05rem;
            float: left;
        }
        .song-info{
            font:0.20rem/0.29rem "宋体";
            color:#fcfcfc;
            float: right;
            margin-top: 0.26rem;
            .song-name{
                float: left;
            }
            .songer{
                color:#7e7e7e;
            }
        }
    }
    .right{
        float: right;
        margin-top:0.3rem;
        img{
            height: 0.4rem;
            margin-right:0.40rem;
        }
        .play{
            
        }
    }
   
}
</style>
