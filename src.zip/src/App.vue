<template>
  <div id="app">
    <Header/>
    <keep-alive include="home">
      <router-view />
    </keep-alive>
    <!-- <Player/> -->
    <Footer />
  </div>
</template>

<script>
import Header from '@/components/Header';
import Footer from '@/components/Footer';
export default {
  components:{
    Header,
    Footer
  }
}
</script>

<style>

</style>
