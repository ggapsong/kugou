<template>
    <div class="searchbar">
      <mt-header title="搜索" class="searchbox">
        <div @click="$router.history.go(-1)" slot="left">
          <mt-button icon="back"></mt-button>
        </div>
      </mt-header>
      这是搜索页面
    </div>
</template>

<script>
export default {
}
</script>

<style>
.searchbar .searchbox{ background: #FFF; color: #333;}
</style>
