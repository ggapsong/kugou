<template>
  <div class="home">
    <mt-navbar v-model="selected">
      <mt-tab-item id="1">
        <router-link to='/'>新歌</router-link>
      </mt-tab-item>
      <mt-tab-item id="2">
        <router-link to='/rank'>排行</router-link>
      </mt-tab-item>
      <mt-tab-item id="3">
        <router-link to="/list">歌单</router-link>
      </mt-tab-item>
      <mt-tab-item id="4">
        <router-link to="/singer">歌手</router-link>
      </mt-tab-item>
    </mt-navbar>
    <router-view />
  </div>
</template>

<script>
export default {

  name: "home",
  data(){
    return {
      selected:"1"
    }
  }
};
</script>
