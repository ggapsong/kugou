<template>
    <div>
        <div class="wrap">
            <mt-swipe :auto="4000">
                <mt-swipe-item v-for="item in banner" :key="item.id" >
                    <img :src="item.imgurl" alt="" class="img">
                </mt-swipe-item>
            </mt-swipe>
        </div>
        <div>
            <SongItem 
                v-for="(item,index) in list" 
                :key="index"
                :fileName="item.filename"
                :hash="item.hash"
            />
        </div>
    </div>
</template>

<script>
import SongItem from '../components/SongItem'
export default {
    components:{
        SongItem
    },
    data(){
        return{
            banner:[],
            list:[]
        }
    },
    created(){
        this.$ajax('/api?json=true').then(({data})=>{
            this.banner = data.banner;
            this.list = data.data;
        });
    },
}
</script>

<style lang="less" scoped>
.wrap{
    height: 2.84rem;
    margin-top: 0.1rem;
    .img{
        height:2.84rem;
        display: block;
        margin: 0 auto;
    }
}
</style>
