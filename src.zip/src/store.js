import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    song: null
  },
  mutations: {
    //payload是hash
    pushSong(state, payload) {
      if(state.song==payload){
        return false;
      };
      state.song=payload;
    }
  },
  actions: {}
});
