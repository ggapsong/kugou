import Vue from "vue";
import Router from "vue-router";
import Home from "./views/Home.vue";
import Search from "./views/Search.vue";
import NewSong from "./views/NewSong.vue";
import Rank from "./views/Rank.vue";
import List from "./views/List.vue";
import Singer from "./views/Singer.vue";
Vue.use(Router);

export default new Router({
  mode: "history",
  base: process.env.BASE_URL,
  routes: [
    {
      path: "/",
      name: "home",
      component: Home,
      children: [
        {
          path: "",
          component: NewSong
        },
        {
          path: "rank",
          component: Rank
        },
        {
          path: "list",
          component: List
        },
        {
          path: "singer",
          component: Singer
        }
      ]
    },
    {
      path: "/search",
      name: "search",
      component: Search
    }
  ]
});
